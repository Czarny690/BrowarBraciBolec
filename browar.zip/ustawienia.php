<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/strona.css">
    <script>
        function previewFile() {
            const file = document.querySelector('input[type="file"]').files[0];
            const preview = document.querySelector('#avatarPreview');
            const reader = new FileReader();
            const Stary = document.getElementById('StaryAvatar')
            reader.onloadend = function () {
                preview.src = reader.result;
                preview.style.display = 'block';
                Stary.style.display = 'none'
            }

            if (file) {
                reader.readAsDataURL(file); 
            } else {
                preview.style.display = 'none';
            }
        }
    </script>
</head>
<body id="bodi1">
  <aside class="menu">
        <nav>
          <a href="strona.php">
            <img src="./images/glowna.png" alt="Główna ikona">
            <span>Główna</span>
          </a>
          <a href="czat.php">
            <img src="./images/czatt.png" alt="Czat ikona">
            <span>Czat</span>
          </a>
          <a href="pdw">
            <img src="./images/galeria.png" alt="Galeria ikona">
            <span>Galeria</span>
          </a>
          <a href="pdw">
            <img src="./images/historia.png" alt="Historia ikona">
            <span>Historia firmy</span>
          </a>
          <a href="ustawienia.php">
            <img src="./images/ustawienia.png" alt="Ustawienia ikona">
            <span>Ustawienia</span>
          </a>
          <form method="post" class="wylogowywanie">
            <button type="submit" name="wyloguj" id="wyloguj">
            <img src="./images/wyloguj.png" alt="Wyloguj ikona">
            <span>Wyloguj się</span>
            </button>
        </form>

        </nav>
      </aside>
    <section id="srodek">  
    <?php 
        $Avatar = "";
        $User = "";
        $Pass = "";
        $Name = "";
        $host = 'localhost';
        $user = 'root';
        $pass = '';
        $dbname = 'moja_baza';
        
        $conn = new mysqli($host, $user, $pass, $dbname);
        
        if ($conn->connect_error) {
            die("Błąd połączenia: " . $conn->connect_error);
        }
        $login = $_COOKIE['czyZalogowany'];
        $q = "SELECT * FROM `daneuzytkownikow` WHERE `User` = '$login'";
        $result = $conn->query($q);
        if ($result && $result->num_rows === 1) {
            $row = $result->fetch_assoc(); 
            if (!empty($row['Avatar'])) {
                $Avatar = "<img id='StaryAvatar' src='" . htmlspecialchars($row['Avatar']) . "' alt='Avatar' width='150';>";
                $User = htmlspecialchars($row['User']);
                $Pass = htmlspecialchars($row['Password']);
                $Name = htmlspecialchars($row['Name']);
                
            } else {
                $Avatar= "Brak avatara.";
            }
        } else {
            $Avatar = "Nie znaleziono użytkownika.";
        }
    ?>
    <form id="forma" method="post" enctype="multipart/form-data"  autocomplete="off">
        Login: <input type="text" name="login" value=<?php echo "$User";?>><br>
        Hasło:<input type="text" name="pass"  value=<?php echo "$Pass";?>><br>
        Nazwa: <input type="text" name="name"  value=<?php echo "$Name";?>><br>
        Zmień swojego avatara: <input type="file" accept="image/*" name="file" onchange="previewFile()"><br>

        <img id="avatarPreview" src="" alt="Podgląd avatara" style="width: 150px; height: 150px; display: none;"><br>

        <?php 
        echo $Avatar;
        ?>
        <br>
        <input type="submit" name="wyslij" value="Potwierdź zmiany">
        <input type="submit" name="zrezygnuj" value="Wyjdź">
    </form>
    <?php 
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['wyslij'])) {
            $NewU = $_POST['login'];
            $NewN = $_POST['name'];
            $NewP = $_POST['pass'];

            $q3 = "SELECT * FROM `daneuzytkownikow` WHERE User = '$NewU';";
            $result = $conn->query($q3);

            if (($result && $result->num_rows === 0) || $NewU === $login) {
                setcookie('czyZalogowany', $NewU, time() + 60 * 60 * 24 * 30, "/");

                $folderDocelowy = 'C:/xampp/htdocs/php/avatary/';
                $staryPlik = $folderDocelowy . "$login.png";
                $nowyPlik = $folderDocelowy . "$NewU.png";

                if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
                    if (file_exists($nowyPlik)) {
                        unlink($nowyPlik);
                    }
                    if (move_uploaded_file($_FILES['file']['tmp_name'], $nowyPlik)) {
                        echo "Nowy plik zapisany jako: " . htmlspecialchars("$NewU.png");
                    } else {
                        echo "Błąd przy zapisie pliku.";
                    }
                } else {
                    if ($login !== $NewU && file_exists($staryPlik)) {
                        rename($staryPlik, $nowyPlik);
                    }
                }

                $q2 = "UPDATE `daneuzytkownikow` 
                       SET User='$NewU', Password='$NewP', Name='$NewN', Avatar='/php/avatary/$NewU.png' 
                       WHERE User='$login'";
                $wynik = mysqli_query($conn, $q2);

                header("Location: strona.php");
            } else {
                echo "Ten login jest już zajęty!";
            }
        }

        if (isset($_POST['zrezygnuj'])) {
            header('Location: strona.php');
        }
    }
    mysqli_close($conn);
    ?>
    </section>
</body>
</html>
