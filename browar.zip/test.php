<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <form method="POST">
  <input type="text" name="name" placeholder="Twoje imię" required>
  <input type="email" name="email" placeholder="Twój e-mail" required>
  <textarea name="message" placeholder="Wiadomość" required></textarea>
  <button type="submit" name="wyslij">Wyślij</button>
</form
    <?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['wyslij'])) {
      $to = "karinajoseph2008@gmail.com";
$subject = "Wiadomość z formularza";
$message = $_POST['message'];
$headers = "From: ".$_POST['email'];

mail($to, $subject, $message, $headers);
echo "Wiadomość została wysłana.";
    }
}
    ?>
</body>
</html>