<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="./css/strona.css?v=30">
        <!-- <audio id="tlo" src="./images/miles.mp3" autoplay loop></audio> -->
    </head>
    <body id="bodi1">
    <aside class="menu">
        <nav>
          <a href="strona.php">
            <img src="./images/glowna.png" alt="Główna ikona">
            <span>Główna</span>
          </a>
          <a href="czat.php">
            <img src="./images/czatt.png" alt="Czat ikona">
            <span>Czat</span>
          </a>
          <a href="pdw">
            <img src="./images/galeria.png" alt="Galeria ikona">
            <span>Galeria</span>
          </a>
          <a href="pdw">
            <img src="./images/historia.png" alt="Historia ikona">
            <span>Historia firmy</span>
          </a>
          <a href="ustawienia.php">
            <img src="./images/ustawienia.png" alt="Ustawienia ikona">
            <span>Ustawienia</span>
          </a>
          <form method="post" class="wylogowywanie">
            <button type="submit" name="wyloguj" id="wyloguj">
            <img src="./images/wyloguj.png" alt="Wyloguj ikona">
            <span>Wyloguj się</span>
            </button>
        </form>

        </nav>
      </aside>
      

    <?php 
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['wyloguj'])) {
            setcookie('czyZalogowany', '', time()-1, '/');
            header("Location: logowanie.php");
            exit;
        }
    }

    if(!isset($_COOKIE['Haslo'])) {
        header("Location: haslo.php");
        exit;
    } else {
        if(isset($_COOKIE['czyZalogowany'])) {
            $Uzytkownik = $_COOKIE['czyZalogowany'];
            setcookie('czyZalogowany', $Uzytkownik, time() + 60*60*24*30, '/'); 

        } else {
            header("Location: logowanie.php");
            exit;
        }
    }

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'moja_baza';

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}
$login = $_COOKIE['czyZalogowany'];
$q = "SELECT * FROM `daneuzytkownikow` WHERE `User` = '$login'";
$result = $conn->query($q);


?>
<header class="gora">
    <h1>Browar Braci Bolec</h1>
    <nav>
        <h4>
        <?php 
        while($row = $result -> fetch_assoc()) {
            $lol=$row['Name'];
            echo "Miło znowu cię widzieć <b>$lol!</b>";
        }
        ?>
        </h4>
    <img src="./images/logo.png" alt="logo">
</nav>
</header>
<main class="majn">
<section class="witamyBlok">
    <h1>Witamy w świecie Piwa!</h1>
</section>
    <aside class="pol1">
         <section id="prostokat1" class="prostokaty">
            <p>Nie jesteśmy zwykłym sklepem. U nas każda butelka ma swoją historię, a każda etykieta opowiada coś więcej niż tylko zawartość alkoholu. Tworzymy przestrzeń dla ludzi, którzy w piwie widzą coś więcej – smak podróży, chwilę wytchnienia, rozmowy przy stole. Niezależnie, czy jesteś fanem lagera, miłośnikiem IPA, czy poszukiwaczem piwnych dziwactw – znajdziesz tu coś dla siebie.</p>
        </section>
        <section id="prostokat2" class="prostokaty">
            <p>Są miejsca w sieci, gdzie ludzie naprawdę słuchają. Nasze forum to jedno z nich. Pogadaj z domowymi piwowarami, zapytaj o najlepsze stouty, poznaj ludzi, którzy tak jak Ty nie traktują piwa jak produktu – tylko jak pasję. Od degustacji w małym miasteczku po relacje z piwnych festiwali – to wszystko dzieje się tutaj. Na spokojnie, bez spiny, z piwem w ręku.</p>
        </section>
        <section id="prostokat3" class="prostokaty">
            <p>Nie jesteśmy kolejnym sklepem z tysiącem etykiet i żadną duszą. Jesteśmy pasjonatami – takimi jak Ty. Zaczynaliśmy od domowego warzenia, ślęczenia nad recepturami i szukania tego jedynego smaku. Dziś tworzymy miejsce, które łączy piwną pasję z dobrą atmosferą. U nas znajdziesz piwa, których nie ma na półkach marketów, historie, które warto poznać, i ludzi, z którymi warto pogadać. Bo piwo to nie tylko napój. To kultura, klimat i wspólnota.</p>
        </section>


<nav id="p1" class="krowa">
        <p>Nasze piwo bezalkoholowe to idealna propozycja dla tych, którzy cenią sobie głęboki smak piwa, ale rezygnują z alkoholu. Dzięki starannie dobranym słodom i chmielom, udało się zachować pełnię aromatu i wyważoną goryczkę, przy jednoczesnym zachowaniu 0% alkoholu. Świeże, lekkie, a jednocześnie wyraziste.</p>
            <img src="./images/dlapizd.png" alt="Dla Pizd" width="531" height="531">
    </nav>
        </aside>
    
        <aside class="pol2">
        <article class="dymek">
            <p>Kto piwa Bolca nie zna, Niech się w ciemności snuje.Bo tam, gdzie Bolec warzy,Sam duch wolności króluje!”</p>
        </article>
        <article class="prostokat"></article>
        <button onclick="zwiekszLicznik()" id="licznik">
        Licznik wypitych piw: 0
    </button>

    <nav id="p2" class="krowa">
        <p>Klasyczny lager w najlepszym, rzemieślniczym wydaniu. Warzony tradycyjnymi metodami, z dbałością o balans pomiędzy słodową pełnią a chmielową goryczką. Klarowny, złocisty i niezwykle pijalny – Classic to propozycja uniwersalna, która sprawdzi się zarówno na co dzień, jak i przy wyjątkowych okazjach.</p>
    <img src="./images/classic.jpg" alt="Klasyczny Klasyk" width="554" height="554">
    
    </nav>    </aside>
    <aside class="pol3">
        <img src="./images/mapa.png" class="mapa">


        <nav id="p3" class="krowa">
         <p>Piwo o zdecydowanym charakterze i intensywnej mocy. Głęboka bursztynowa barwa, bogata paleta smaków i aromatów oraz solidna zawartość alkoholu sprawiają, że to piwo dla koneserów ceniących siłę i głębię rzemieślniczego piwowarstwa. Doskonałe do powolnej degustacji i odkrywania kolejnych warstw smaku.</p>
            <img src="./images/strong.png" alt="Mocarny" width="554" height="554">
    </nav>
        </aside>
        <footer>
                <p>Artur Holek zmusił mnie do robienia tego w wolnym czasie bez możliwości przerwy na szluga</p>
            </footer>
    </main>
        <script>
            let butt = document.getElementById("licznik")
            function zwiekszLicznik() {
                let czajnik
                if(localStorage.getItem("czajnik")) {
                    czajnik=parseInt(localStorage.getItem("czajnik"))
                } else {
                    localStorage.setItem("czajnik", 0);
                    czajnik=0;
                }
                czajnik++
                localStorage.setItem("czajnik", czajnik)

                butt.textContent = "Licznik wypitych piw: " + czajnik
            }
            let czaj
               if(localStorage.getItem("czajnik")) {
                    czaj=parseInt(localStorage.getItem("czajnik"))
                } else {
                    localStorage.setItem("czajnik", 0);
                    czaj=0;
                }
            butt.textContent ="Licznik wypitych piw: " +  czaj
            
    </script>
</body>
</html>
