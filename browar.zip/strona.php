<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="./css/strona.css?v=16">
        <audio id="tlo" src="./images/miles.mp3" autoplay loop></audio>
    </head>
    <body id="bodi1">
    <aside class="menu">
        <nav>
          <a href="strona.php">
            <img src="./images/glowna.png" alt="Główna ikona">
            <span>Główna</span>
          </a>
          <a href="czat.php">
            <img src="./images/czatt.png" alt="Czat ikona">
            <span>Czat</span>
          </a>
          <a href="pdw">
            <img src="./images/galeria.png" alt="Galeria ikona">
            <span>Galeria</span>
          </a>
          <a href="pdw">
            <img src="./images/historia.png" alt="Historia ikona">
            <span>Historia firmy</span>
          </a>
          <a href="ustawienia.php">
            <img src="./images/ustawienia.png" alt="Ustawienia ikona">
            <span>Ustawienia</span>
          </a>
        </nav>
      </aside>
      
    <form method="post">
        <input type="submit" value="Wyloguj się" name="wyloguj">
    </form>

    <?php 
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['wyloguj'])) {
            setcookie('czyZalogowany', '', time()-1, '/');
            header("Location: logowanie.php");
            exit;
        }
    }

    if(!isset($_COOKIE['Haslo'])) {
        header("Location: haslo.php");
        exit;
    } else {
        if(isset($_COOKIE['czyZalogowany'])) {
            $Uzytkownik = $_COOKIE['czyZalogowany'];
            setcookie('czyZalogowany', $Uzytkownik, time() + 60*60*24*30, '/'); 

        } else {
            header("Location: logowanie.php");
            exit;
        }
    }
    ?>


<?php

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'moja_baza';

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}
$login = $_COOKIE['czyZalogowany'];
$q = "SELECT * FROM `daneuzytkownikow` WHERE `User` = '$login'";
$result = $conn->query($q);

if ($result && $result->num_rows === 1) {
    $row = $result->fetch_assoc();
    echo "Zalogowano jako: " . htmlspecialchars($row['User']) . "<br>";
    
    if (!empty($row['Avatar'])) {
        echo "<img src='" . htmlspecialchars($row['Avatar']) . "' alt='Avatar' width='150'>";
        
    } else {
        echo "Brak avatara.";
    }
} else {
    echo "Nie znaleziono użytkownika.";
}

mysqli_close($conn);
       ?>
<!-- <script>
    const audio = document.getElementById('muzyka');

    let zapisanyCzas = localStorage.getItem('czas');
    if (zapisanyCzas !== null) {
        zapisanyCzas = parseFloat(zapisanyCzas);
    }

    // Poczekaj aż strona będzie gotowa
    window.addEventListener('DOMContentLoaded', () => {
        // Poczekaj na interakcję użytkownika
        document.body.addEventListener('click', () => {
            if (zapisanyCzas !== null) {
                audio.currentTime = zapisanyCzas;
            }

            audio.play().catch(err => {
                console.warn('Nie udało się odtworzyć audio:', err);
            });
        }, { once: true }); // tylko przy pierwszym kliknięciu
    });

    // Zapisuj aktualny czas co 0.5 sekundy
    setInterval(() => {
        if (!audio.paused && !audio.seeking) {
            localStorage.setItem('czas', audio.currentTime);
        }
    }, 500);
</script> -->


</body>
</html>
