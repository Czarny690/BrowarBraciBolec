CREATE DATABASE IF NOT EXISTS moja_baza
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE moja_baza;

CREATE TABLE daneuzytkownikow (
    User VARCHAR(20) NOT NULL PRIMARY KEY,
    Password VARCHAR(64) NOT NULL,
    Name VARCHAR(30) NOT NULL,
    Avatar VARCHAR(255) DEFAULT NULL,
    Ranga varchar(255) DEFAULT null
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


CREATE TABLE wpisy (
    User VARCHAR(30) DEFAULT NULL PRIMARY KEY,
    Avatar VARCHAR(255) DEFAULT NULL,
    Tresc VARCHAR(255) DEFAULT NULL,
    Data DATETIME DEFAULT CURRENT_TIMESTAMP,
    Polubienia INT(10) DEFAULT NULL,
    Rodzaj INT(10) DEFAULT NULL,
    Nazwa VARCHAR(30) DEFAULT NULL,
    Zdjecie VARCHAR(255) DEFAULT NULL,
    ID INT(255) DEFAULT NULL,
    Rodzic INT(9) DEFAULT NULL
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `daneuzytkownikow` 
add COLUMN IloscWiadomosci int(255);
