CREATE DATABASE IF NOT EXISTS moja_baza
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE moja_baza;

CREATE TABLE daneuzytkownikow (
    User VARCHAR(20) NOT NULL PRIMARY KEY,
    Password VARCHAR(64) NOT NULL,
    Name VARCHAR(30) NOT NULL,
    Avatar VARCHAR(255),
    Ranga varchar(255)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


CREATE TABLE wpisy (
    User VARCHAR(30) PRIMARY KEY,
    Avatar VARCHAR(255),
    Tresc VARCHAR(255),
    Data DATETIME DEFAULT CURRENT_TIMESTAMP,
    Polubienia INT(10),
    Rodzaj INT(10),
    Nazwa VARCHAR(30),
    Zdjecie VARCHAR(255),
    ID INT(255),
    Rodzic INT(9)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE daneuzytkownikow 
add COLUMN IloscWiadomosci int(255);