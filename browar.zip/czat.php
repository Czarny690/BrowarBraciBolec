<?php
ob_start();

$limit = 5;
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'moja_baza';

$login = $_COOKIE['czyZalogowany'] ?? '';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}


$Nazwa = '';
$Avatar = '';
if (!empty($login)) {
    $ZnajdzOsobe = "SELECT * FROM `daneuzytkownikow` WHERE User = '$login';";
    $wynik = mysqli_query($conn, $ZnajdzOsobe);
    if (mysqli_num_rows($wynik) == 1) {
        $row = mysqli_fetch_assoc($wynik);
        $Nazwa = $row['Name'];
        $Avatar = $row['Avatar'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['like'])) {
        $idKom=$_POST['idKom'];
        $znajdzKom = "select * from `wpisy` where `ID`='$idKom';";
        $wynik = mysqli_query($conn, $znajdzKom);
        $row = mysqli_fetch_assoc($wynik);
        $like=$row['Polubienia']+1;
        $zwiekszLike="update `wpisy` set `Polubienia` = $like where `ID`= '$idKom';";
        $conn -> query($zwiekszLike);
        header("Location: czat.php");

    }

    if (isset($_POST['wyslij'])) {
        if (
            !empty(trim($_POST['wiadomosc'])) || 
            (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK)
        ) {        
        $ID = rand(1000, 999999999);
        $wiadomosc='';
        if(!empty(isset($_POST['wiadomosc']))) {
        $wiadomosc = mysqli_real_escape_string($conn, $_POST['wiadomosc']);
        }
        $Zdjecie = ''; 

        $folderDocelowy = 'C:/xampp/htdocs/php/czat/';
        $nowyPlik = $folderDocelowy . "$login-$ID.png";
        $sciezka = "/php/czat/$login-$ID.png";
        if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
            if (move_uploaded_file($_FILES['file']['tmp_name'], $nowyPlik)) {
                $Zdjecie = "$login-$ID.png"; 
                echo "Nowy plik zapisany jako: " . htmlspecialchars($Zdjecie);
            } else {
                echo "Błąd przy zapisie pliku.";
            }
        } else {
            echo "Brak pliku lub błąd pliku!";
        }

        $message = "INSERT INTO `wpisy` (ID, User, Nazwa, Avatar, Tresc, Polubienia, Rodzaj, Zdjecie) 
                    VALUES ($ID, '$login', '$Nazwa', '$Avatar', '$wiadomosc', 0, 1, '$sciezka');";
        mysqli_query($conn, $message);
        $ilosc="update `daneuzytkownikow` set `iloscWiadomosci` = `iloscWiadomosci`+1 where `User`='$login';";
        $conn -> query($ilosc);
       $ilosc2 = "SELECT `iloscWiadomosci`, `Ranga` FROM `daneuzytkownikow` WHERE `User` = '$login';";
$result = $conn->query($ilosc2);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $wiadomosci = $row['iloscWiadomosci'];
    $rangaObecna = $row['Ranga'];

    $nowaRanga = null;

    if ($rangaObecna != "Mędrzec kufla" && $rangaObecna != "Mistrz Browaru") {
        if ($wiadomosci > 180) {
            $nowaRanga = "Piwowładca";
        } else if ($wiadomosci > 130) {
            $nowaRanga = "Stały Bywalec";
        } else if ($wiadomosci > 90) {
            $nowaRanga = "Gawędziarz";
        } else if ($wiadomosci > 60) {
            $nowaRanga = "Degustator";
        } else if ($wiadomosci > 25) {
            $nowaRanga = "Piwosz";
        }

        if ($nowaRanga && $nowaRanga != $rangaObecna) {
            $zmienRange = "UPDATE `daneuzytkownikow` SET `Ranga` = '$nowaRanga' WHERE `User` = '$login';";
            $conn->query($zmienRange);
        }
    }
}

        
        header('Location: czat.php');
        exit;
    }
}
if(isset($_POST['odpowiedz']) && !empty($_POST['odpowiedz'])) {
    $ID = rand(1000, 999999999);
    $tekst = $_POST['odpowiedz'];
    $sciezka = "/php/czat/$login-$ID.png";
    $rodzic = $_POST['rodzic'];
    $message = "INSERT INTO `wpisy` (ID, User, Nazwa, Avatar, Tresc, Polubienia, Rodzaj, Zdjecie, Rodzic) 
                    VALUES ($ID, '$login', '$Nazwa', '$Avatar', '$tekst', 0, 2, '$sciezka', '$rodzic');";
        $conn -> query($message);
    header("Location: czat.php");
}
}

$usunNajstarsze = "SELECT COUNT(*) AS `ile` FROM `wpisy` WHERE `Rodzaj` = 1;";
$result = mysqli_query($conn, $usunNajstarsze);
if ($result) {
    $row = $result->fetch_assoc();
    $count = $row['ile'];

    if ($count > $limit) {
        $usun = $count - $limit;

        $pobierzDoUsuniecia = "SELECT `ID`, `Zdjecie` FROM `wpisy` WHERE `Rodzaj` = 1 ORDER BY `Data` ASC LIMIT $usun;";
        $wynikiDoUsuniecia = mysqli_query($conn, $pobierzDoUsuniecia);

        if ($wynikiDoUsuniecia) {
            while ($wiersz = mysqli_fetch_assoc($wynikiDoUsuniecia)) {
                $rodzic=$wiersz['ID'];
                $usunKom= "delete from `wpisy` where `Rodzic` = '$rodzic';";
                $conn -> query($usunKom);
                $sciezka = 'C:/xampp/htdocs' . $wiersz['Zdjecie'];
                if (!empty($wiersz['Zdjecie']) && file_exists($sciezka)) {
                    unlink($sciezka);
                }
            }
        }

        $doUsuniecia = "DELETE FROM `wpisy` WHERE `Rodzaj` = 1 ORDER BY `Data` ASC LIMIT $usun;";
        mysqli_query($conn, $doUsuniecia);
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Czat</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="./css/czat.css?v=567">
    <link rel="stylesheet" href="./css/strona.css?v=892">

   <script>
    let zaczynac=false;
let intervalId; 
let aktualnePoleOdpowiedzi = null;
let pierwszyRaz = true; 

function wyslijWiadomosc(User, Avatar, Nazwa, Czas, Tresc, id, klasa, fota, polubienia, Ranga) {
    clearInterval(intervalId);
    let stworzBlokKom = document.createElement('article');
    let blokWiadomosci = document.getElementsByClassName('WszystkieKomentarze')[0];
    
    stworzBlokKom.classList.add(`blokWiadomosc-${id}`);
    stworzBlokKom.id = klasa;
    stworzBlokKom.innerHTML = `
        <img src="${Avatar}" class="WiadomoscAvatar">
        <header>${Nazwa}</header>
        <header>${Ranga}</header>
        <time>${Czas}</time><br>
        <img src="${fota}" class="ZdjecieWiadomosc" alt="" style="min-width: 20vw; max-width:25vw">
        <section class="WiadomoscTresc">${Tresc}</section>
        <form action="czat.php" method="POST" class="serca">
            <input type="submit" value="❤️ ${polubienia}" name="like">
            <input type="hidden" value="${id}" name="idKom">
        </form>
        <aside class="komNapis">Komentarze</aside>
        <section class="WiadomoscKomentarze" id="kom-${id}"></section>
        <nav onclick="Odpowiedz('${User}', '${id}')" id="odpowiedz">Odpowiedz</nav>
    `;
    blokWiadomosci.appendChild(stworzBlokKom);
}

function Odpowiedz(User, id) {
    clearInterval(intervalId);

    if (aktualnePoleOdpowiedzi) {
        aktualnePoleOdpowiedzi.remove();
        aktualnePoleOdpowiedzi = null;
    }
    let oknoOdpowiedzi = document.createElement('form');
    oknoOdpowiedzi.method = 'POST';
    oknoOdpowiedzi.id = "okno";
    oknoOdpowiedzi.classList.add(User);
    oknoOdpowiedzi.autocomplete = "off";
    oknoOdpowiedzi.innerHTML = `
        <input placeholder="Wpisz odpowiedź..." type="text" name="odpowiedz" id="poleOdpowiedz" autofocus>
        <input type="hidden" name="rodzic" value="${id}">
    `;

    let KonkretnyKom = document.getElementsByClassName(`blokWiadomosc-${id}`)[0];
    KonkretnyKom.appendChild(oknoOdpowiedzi);
    oknoOdpowiedzi.querySelector('#poleOdpowiedz').focus();

    aktualnePoleOdpowiedzi = oknoOdpowiedzi;
}

function przewinNaDol() {
       if (pierwszyRaz) {
                const savedScroll = localStorage.getItem("scroll");
                setTimeout(() => {
                    if (savedScroll !== null) {
                        window.scrollTo({ top: parseInt(savedScroll), behavior: "auto" });
                        localStorage.removeItem("scroll"); 
                    } else {
                        window.scrollTo({ top: document.body.scrollHeight });
                    }
                    pierwszyRaz = false;
                }, 250);
            }
}

function zapamietajPozycje() {
    const scrollY = window.scrollY;
    localStorage.setItem("scroll", scrollY);
}

function pobierzWiadomosci() {
    if (document.getElementById('poleOdpowiedz')) {
        return; 
    }

    $.ajax({
        url: "pobierz_wiadomosci.php",
        method: "GET",
        success: function(data) {
            const wiadomości = JSON.parse(data);
            const blokWiadomosci = document.getElementsByClassName('WszystkieKomentarze')[0];
            blokWiadomosci.innerHTML = '';

            wiadomości.forEach(function(wiadomosc) {
                wyslijWiadomosc(
                    wiadomosc.User,
                    wiadomosc.Avatar,
                    wiadomosc.Nazwa,
                    wiadomosc.Czas,
                    wiadomosc.Tresc,
                    wiadomosc.ID,
                    wiadomosc.Klasa, 
                    wiadomosc.Zdjecie,
                    wiadomosc.Polubienia,
                    wiadomosc.Ranga
                );
            });
        
        }
    });
}

function dodajKomentarz(idWiado, tresc, nazwa, avatar, data, polubienia, idKom) {
    setTimeout(() => {
        let rodzicWiado = document.getElementById(`kom-${idWiado}`);
        let stworzKomBlok = document.createElement('section');
        stworzKomBlok.id = 'gowno'
        stworzKomBlok.innerHTML = `
            <img src="${avatar}" class="AvKom">
            <header>@${nazwa}</header>
            <time>${data}</time>
            <section class="TrescKom">${tresc}</section>
            <form action="czat.php" method="POST" class="serca">
                <input type="submit" value="❤️ ${polubienia}" name="like">
                <input type="hidden" value="${idKom}" name="idKom">
            </form>
        `;
        rodzicWiado.appendChild(stworzKomBlok);
    }, 500);
}

function PodgladImg() {
    const file = document.querySelector('input[type="file"]').files[0];
    const reader = new FileReader();
    const obrazek = document.getElementById('obrazek');
    const ikona = document.getElementById('penis');

    reader.onloadend = function () {
        obrazek.src = reader.result;
        obrazek.style.display = 'block';
        ikona.style.display = 'none';
    };
    reader.readAsDataURL(file); 
}

$(document).ready(function() {
    pobierzWiadomosci();
    intervalId = setInterval(pobierzWiadomosci, 3000);

    document.getElementById('body').addEventListener('click', (event) => {
        if (
            aktualnePoleOdpowiedzi &&
            !aktualnePoleOdpowiedzi.contains(event.target) &&
            event.target.tagName !== 'NAV'
        ) {
            aktualnePoleOdpowiedzi.remove(); 
            aktualnePoleOdpowiedzi = null;  
        }
    });


$(document).on('submit', 'form.serca', function() {
    zapamietajPozycje();
});

$(document).on('submit', 'form#okno', function() {
    zapamietajPozycje();
});

});
</script>

</head>
<body id="body">
    <aside class="poboczne">
        <img src="./images/logo.png">
        <h1 class="nazwa">Browar Braci <br>Bolec</h1>
        <h1 class="nazCzat">Piwny Czat</h1>
         <p>Zapraszamy do rozmów przy kuflu – o piwie, historii i życiu. Tradycja łączy pokolenia, tak jak wspólny toast.</p>
         <p class="text2">Za każde wypowiedziane słowo w kuflowej rozmowie zyskujesz coś więcej niż towarzystwo – zdobywasz rangę. Im więcej słów, tym pełniejszy kufel uznania.</p>
    </aside>
<aside class="menu">
    <nav>
        <a href="strona.php"><img src="./images/glowna.png" alt="Główna ikona"><span>Główna</span></a>
        <a href="czat.php"><img src="./images/czatt.png" alt="Czat ikona"><span>Czat</span></a>
        <a href="pdw"><img src="./images/galeria.png" alt="Galeria ikona"><span>Galeria</span></a>
        <a href="pdw"><img src="./images/historia.png" alt="Historia ikona"><span>Historia firmy</span></a>
        <a href="ustawienia.php"><img src="./images/ustawienia.png" alt="Ustawienia ikona"><span>Ustawienia</span></a>
    
           <form method="post" class="wylogowywanie" style="margin-left: 1vw;">
            <button type="submit" name="wyloguj" id="wyloguj">
            <img src="./images/wyloguj.png" alt="Wyloguj ikona">
            <span>Wyloguj się</span>
            </button>
        </form>
    </nav>
</aside>

<a href="#"></a><br>
<form action="czat.php" method="post" autocomplete="off"  enctype="multipart/form-data">
    <input type="text" name="wiadomosc" placeholder="Wpisz wiadomość" autofocus>
    <input type="submit" name="wyslij" value="Wyślij">
    <nav class="przyciskImg">
        <input type="file" accept="image/*" name="file" onchange="PodgladImg()">
        <img class="zdjecie" id="penis" src="./images/zdjecia1.png">
        <img id="obrazek">
    </nav>
        <footer>
            <?php 
            $ZnajdzOsobe = "SELECT * FROM `daneuzytkownikow` WHERE User = '$login';";
            $wynik = mysqli_query($conn, $ZnajdzOsobe);
            $row = $wynik->fetch_assoc();
                $zdj = $row['Avatar'];
                $name = $row['Name'];
                echo "<p>Zalogowano jako <b>$name</b></p><br>";
                echo "<aside>@". $row['User']. "</aside>";
                echo "<img src='$zdj' id='zdj'>";
                
                ?>
        </footer>
        
    </form>
    <footer id="tlo">
        </footer>
        <main class="WszystkieKomentarze"></main>
        <?php 
    $pobierzKomentarze = "select * from `wpisy` where `Rodzaj`= 2";
    $wynik = mysqli_query($conn, $pobierzKomentarze);
    while ($wiersz = mysqli_fetch_assoc($wynik)) {
        $idWiadomosci = $wiersz['Rodzic'];
        $id=$wiersz['ID'];
        $tresc= $wiersz['Tresc'];
        $nazwa = $wiersz['Nazwa'];
        $avatar=$wiersz['Avatar'];
        $data=$wiersz['Data'];
        $polubienia=$wiersz['Polubienia'];
        echo "
        <script>
        dodajKomentarz('$idWiadomosci', '$tresc', '$nazwa', '$avatar', '$data', '$polubienia', '$id')
        </script>
        ";
    }
$q69 = "SELECT * FROM `wpisy` WHERE `Rodzaj` = 1;";
$result69 = $conn->query($q69);

while ($row = $result69->fetch_assoc()) {
    $id = $row['ID'];
    $q70 = "SELECT COUNT(`Rodzic`) AS liczba FROM `wpisy` WHERE `Rodzic` = '$id';";
    $ress = $conn->query($q70);
    if ($ress) {
        $countRow = $ress->fetch_assoc();
        if ($countRow['liczba'] > 3) {
            echo "<script>
    setTimeout(() => {  
        let wybranyDiv = document.querySelector('.blokWiadomosc-$id');
        wybranyDiv.dataset.user='duzoKom'
    }, 250);
            </script>";
        }
    } else {
        echo "Błąd zapytania: " . $conn->error;
    }
}

$conn->close();
?>
<script>

function f1() {
    setTimeout(() => {
        const kontenery = document.querySelectorAll('[data-user="duzoKom"]');
        kontenery.forEach(kontener => {
            const sekcje = kontener.querySelectorAll('.WiadomoscKomentarze #gowno');
            const stworzGowno = document.createElement('p')
            stworzGowno.textContent = "🔻 Rozwiń"
            stworzGowno.id='japidi'
  sekcje.forEach((sekcja, index) => {
    if (index > 1 && index < 3) {
      sekcja.className = 'kutas';
      sekcja.after(stworzGowno)
    }
    if(index > 2) {
        sekcja.style.display = 'none'
    }
  });
});

}, 550);
}



</script>

<?php 
echo "<script>
f1()
przewinNaDol()

</script>"
?>
</body>
</html>
