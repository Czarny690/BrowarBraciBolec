<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'moja_baza';

$conn = new mysqli($host, $user, $pass, $dbname);

$login = $_COOKIE['czyZalogowany'] ?? null;

if (!$login) {
    echo json_encode(['error' => 'Nie zalogowano']);
    exit;
}

$znajdzRange = "SELECT * FROM `daneuzytkownikow` WHERE `User` = '$login'";
$resultRanga = $conn->query($znajdzRange);
$ranga = null;

if ($resultRanga && $resultRanga->num_rows > 0) {
    $rowRanga = $resultRanga->fetch_assoc();
    $ranga = $rowRanga['Ranga'];
    $user=$rowRanga['User'];
    $avatar=$rowRanga['Avatar'];
    $nazwa=$rowRanga['Name'];
}

$znajdzWpisy = "SELECT * FROM `wpisy` WHERE `Rodzaj`=1 ORDER BY `Data` ASC";
$wszystkieWpisy = $conn->query($znajdzWpisy);
$wiadomosci = [];

if ($wszystkieWpisy && $wszystkieWpisy->num_rows > 0) {
    while ($row = $wszystkieWpisy->fetch_assoc()) {
        $klasa = ($row['User'] == $login) ? 'gracz' : 'inna'; 
        $wiadomosci[] = [
            'User' => $user,
            'Avatar' => $avatar,
            'Tresc' => $row['Tresc'],
            'Nazwa' => $nazwa,
            'Czas' => $row['Data'],
            'ID' => $row['ID'],
            'Klasa' => $klasa,
            'Zdjecie'=> $row['Zdjecie'],
            'Polubienia'=>$row['Polubienia'],
            'Ranga'=>$ranga
        ];
    }
}

echo json_encode($wiadomosci);

$conn->close();
?>
